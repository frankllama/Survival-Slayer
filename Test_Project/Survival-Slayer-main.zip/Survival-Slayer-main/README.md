# Survival-Slayer

To run game, in terminal/ IDE: python3 main.py

## Controls
Movement: Arrow Keys <br />
Weapon Attack: Space <br />
Magic attack: Left Ctrl <br />
Switch Weapons: q <br />
Switch Magic: e <br />
Menu/ Upgrade window: m <br />

## Credits
Some sprites and maps are original.

Some sprites, 1 map, and music: <br />
Pixel-Boy and AAA <br />
Link to their Website: https://pixel-boy.itch.io/ninja-adventure-asset-pack <br />
Their Patreon: https://www.patreon.com/pixelarchipel <br />
Their License used: released under the Creative Commons Zero (CC0) license. <br />
